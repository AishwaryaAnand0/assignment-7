/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>
int main() 
{
   int i,j, b,n= 0;
   printf("Enter the number of rows: ");
   scanf("%d",&b);
   for (i = 1;i<=b;++i,n= 0) 
   {
      for (j=1;j<=b-i;++j)
      {
         printf("  ");
      }
      while (n!=2*i-1)
      {
         printf("* ");
         ++n;
      }
      printf("\n");
   }
   return 0;
}












